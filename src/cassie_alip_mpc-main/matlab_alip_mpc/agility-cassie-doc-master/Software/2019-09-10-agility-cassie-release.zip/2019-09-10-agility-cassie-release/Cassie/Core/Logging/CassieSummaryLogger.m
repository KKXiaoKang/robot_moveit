% CASSIESUMMARYLOGGER Logs summary data each time the robot is turned on
%
%    Reference page in Doc Center
%       doc CassieSummaryLogger
%
%