% ELMOMODULE Elmo amplifier module
%
%    Reference page in Doc Center
%       doc ElmoModule
%
%