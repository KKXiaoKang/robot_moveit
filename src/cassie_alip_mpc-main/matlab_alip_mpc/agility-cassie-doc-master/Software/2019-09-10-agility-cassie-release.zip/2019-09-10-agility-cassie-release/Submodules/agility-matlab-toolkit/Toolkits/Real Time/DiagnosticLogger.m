% DIAGNOSTICLOGGER Diagnostic logging system
% 
%  Description:
%    This system acts as the global logger for DiagnosticCodes. It can be
%    passed by reference to various subsystems which can each publish
%    messages to the logger.
%
%    Reference page in Doc Center
%       doc DiagnosticLogger
%
%