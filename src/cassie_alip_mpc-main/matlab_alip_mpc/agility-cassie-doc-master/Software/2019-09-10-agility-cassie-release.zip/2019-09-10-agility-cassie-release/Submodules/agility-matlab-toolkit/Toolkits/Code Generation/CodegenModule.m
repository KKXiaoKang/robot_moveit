% CODEGENMODULE Code generation module
%
%    Reference page in Doc Center
%       doc CodegenModule
%
%