% FUNCTION Abstract function object
% 
%  Description:
%    This implements an abstract class for building functionality on top
%    of functions.
%
%    Reference page in Doc Center
%       doc Function
%
%