% CASSIECALIBRATION Cassie calibration data structure
%
%    Reference page in Doc Center
%       doc CassieCalibration
%
%