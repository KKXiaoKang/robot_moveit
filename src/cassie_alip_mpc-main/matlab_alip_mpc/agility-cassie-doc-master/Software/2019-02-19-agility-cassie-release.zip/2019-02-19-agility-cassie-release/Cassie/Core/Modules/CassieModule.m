% CASSIEMODULE Cassie module
%
%    Reference page in Doc Center
%       doc CassieModule
%
%