% BUSMODULE Bus module
%
%    Reference page in Doc Center
%       doc BusModule
%
%