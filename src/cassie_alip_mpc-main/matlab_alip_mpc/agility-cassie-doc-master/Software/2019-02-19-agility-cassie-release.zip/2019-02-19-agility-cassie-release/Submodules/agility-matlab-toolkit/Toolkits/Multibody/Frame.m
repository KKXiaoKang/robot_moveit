% FRAME Implements a reference frame object
% 
%  Syntax:
%    frame = Frame('Name', parentFrame)
%
%    Reference page in Doc Center
%       doc Frame
%
%