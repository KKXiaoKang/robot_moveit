% FILTERSYSTEM Implements a MATLAB system filter block
%
%    Reference page in Doc Center
%       doc FilterSystem
%
%