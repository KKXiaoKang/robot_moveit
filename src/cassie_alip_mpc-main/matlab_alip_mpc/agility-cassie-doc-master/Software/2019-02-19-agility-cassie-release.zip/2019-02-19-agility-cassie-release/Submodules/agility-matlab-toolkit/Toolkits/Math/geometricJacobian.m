% GEOMETRICJACOBIAN Compute symbolic geometric Jacobian of a transformation
% 
%  Syntax:
%    J = geometricJacobian(T, q)
%