% FLOATINGBASEJOINT Implements a floating base (6DOF) joint object
% 
%  Syntax:
%    joint = FloatingBaseJoint('Name', parentFrame)
%
%    Reference page in Doc Center
%       doc FloatingBaseJoint
%
%