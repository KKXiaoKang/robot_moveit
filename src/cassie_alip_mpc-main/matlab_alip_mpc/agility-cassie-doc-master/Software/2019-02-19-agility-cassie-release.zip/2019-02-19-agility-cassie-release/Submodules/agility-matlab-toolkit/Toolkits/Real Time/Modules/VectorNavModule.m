% VECTORNAVMODULE VectorNav module
%
%    Reference page in Doc Center
%       doc VectorNavModule
%
%